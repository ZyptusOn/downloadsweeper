@echo off
setlocal
pushd "%~dp0"
if not exist "config.toml" copy /Y "config.example.toml" "config.toml" >nul
ds-web.exe --open %*
set "DS_EXIT_CODE=%ERRORLEVEL%"
popd
if not "%DS_EXIT_CODE%"=="0" pause
exit /b %DS_EXIT_CODE%